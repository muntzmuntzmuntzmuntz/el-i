package com.mememe;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.facebook.AccessToken;
import com.facebook.AccessTokenTracker;
import com.facebook.CallbackManager;
import com.facebook.login.Login;
import com.facebook.login.LoginManager;
import com.facebook.login.widget.LoginButton;
import com.mememe.models.User;
import com.skydoves.colorpickerview.ColorEnvelope;
import com.skydoves.colorpickerview.ColorPickerDialog;
import com.skydoves.colorpickerview.listeners.ColorEnvelopeListener;

import de.hdodenhof.circleimageview.CircleImageView;

public class MemesengerActivity extends Activity {
    User user;

    private CircleImageView circleImageView;

    private PaintView paintView;

    private Button setColorButton, setSizeButton, setBackgroundButton;
    DisplayMetrics metrics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_memesenger);

        setColorButton = findViewById(R.id.brush_color);
        setSizeButton = findViewById(R.id.brush_size);
        setBackgroundButton = findViewById(R.id.background_color);


        circleImageView = findViewById(R.id.profile_image);

        user = getIntent().getParcelableExtra("user");
        checkUser();

        paintView = findViewById(R.id.paintView);
        try{
            metrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(metrics);

//            paintView.invalidate();
            paintView.init(metrics,Color.RED,5);
            paintView.normal();
        }catch (Exception e){
            Log.e(">> GG", "GG" +e);
        }
    }

    public void profileOnClick(View v){
        logout();
    }

    public void checkUser(){
        Toast.makeText(MemesengerActivity.this,"USER: "+user.getName(),Toast.LENGTH_LONG).show();
        if (!user.getId().equals("")){
            Glide.with(MemesengerActivity.this).load(user.getImage_url()).into(circleImageView);
        }
    }

    public void logout(){
        AlertDialog.Builder builder = new AlertDialog.Builder(MemesengerActivity.this);
        builder.setMessage("CONFIRM LOGOUT?");

        builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                LoginManager.getInstance().logOut();

                Intent intent = new Intent(MemesengerActivity.this,MainActivity.class);
                intent.putExtra("status","logout");
                startActivity(intent);
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User cancelled the dialog
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public void setColor(View view) {
        new ColorPickerDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("ColorPicker Dialog")
                .setPreferenceName("MyColorPickerDialog")
                .setPositiveButton(getString(R.string.confirm),
                        new ColorEnvelopeListener() {
                            @Override
                            public void onColorSelected(ColorEnvelope envelope, boolean fromUser) {
//                                setLayoutColor(envelope);
                            }
                        }).
                setNegativeButton(getString(R.string.cancel),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                })
                .attachAlphaSlideBar(true) // default is true. If false, do not show the AlphaSlideBar.
                .attachBrightnessSlideBar(true)  // default is true. If false, do not show the BrightnessSlideBar.
                .show();
        paintView.setBrushColor(Color.BLACK);
        paintView.init(metrics,Color.BLACK,5);
    }

    public void setSize(View view) {
        paintView.setBrushWidth(5);
        paintView.init(metrics,Color.BLUE,10);
    }
}
